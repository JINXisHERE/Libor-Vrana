package minesweepermain;
import java.util.Random;
public class MinesweeperMain {

    public static void main(String[] args) {
        Random rand = new Random();
        int x_max = 10;
        int y_max = 10;
        int x, y;
        int[][] array = new int[x_max][y_max];

        y = 0;
        while (y_max > y) {
            x = 0;
            while (x_max > x) {
                array[x][y] = 0;
                x++;
            }
            y++;
        }

        //miny
        int i = 0;
        int n = rand.nextInt(10) + 1;
        while (i < n) {
            x = rand.nextInt(x_max);
            y = rand.nextInt(y_max);
            if(array[x][y] != 9){
                array[x][y] = 9;
            i++;
            }
        }

        //hodnoty
        y = 0;
        while (y_max > y) {
            x = 0;
            while (x_max > x) {
                //mina
                if (array[x][y] == 9) {
                    if (x - 1 >= 0 && y - 1 >= 0 && array[x - 1][y - 1] != 9) {
                        array[x - 1][y - 1] += 1;
                    }
                    if (y - 1 >= 0 && array[x][y - 1] != 9) {
                        array[x][y - 1] += 1;
                    }
                    if (x + 1 < x_max && y - 1 >= 0 && array[x + 1][y - 1] != 9) {
                        array[x + 1][y - 1] += 1;
                    }
                    if (x - 1 >= 0 && array[x - 1][y] != 9) {
                        array[x - 1][y] += 1;
                    }
                    if (x + 1 < x_max && array[x + 1][y] != 9) {
                        array[x + 1][y] += 1;
                    }
                    if (x - 1 >= 0 && y + 1 < y_max && array[x - 1][y + 1] != 9) {
                        array[x - 1][y + 1] += 1;
                    }
                    if (y + 1 < y_max && array[x][y + 1] != 9) {
                        array[x][y + 1] += 1;
                    }
                    if (x + 1 < x_max && y + 1 < y_max && array[x + 1][y + 1] != 9) {
                        array[x + 1][y + 1] += 1;
                    }
                }
                x++;
            }
            y++;
        }

        //výstup
        y = 0;
        while (y_max > y) {
            x = 0;
            System.out.print(y + " ");
            while (x_max > x) {
                    System.out.print(array[x][y] + " ");
                x++;
            }
            System.out.println();
            y++;
        }
    }
}
